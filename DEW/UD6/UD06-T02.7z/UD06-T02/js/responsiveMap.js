var query900 = Modernizr.mq('(min-width: 1920px)');
var query768 = Modernizr.mq('(min-width: 768px)');
var lat,
	long,
	zoom;
if (query900) {
	lat = 52.5840664;
	long = 31.0702264;
	zoom = 4;
} else if (query768) {
	lat = 52.263063;
	long = 19.556182;
	zoom = 4;
} else {
	lat = 51.992581;
	long = 16.919815;
	zoom = 3;
}

/**
 * 
 * @param {*} pointer 
 * @param {*} infoCourse 
 */
function myMap(infoCourse, newMarker) {
	let myCenter = new google.maps.LatLng(lat, long);
	if (infoCourse != undefined)
		if (infoCourse.length == 1){
			zoom = 7;
			myCenter = {lat: infoCourse[0][2][0], lng: infoCourse[0][2][1]};
		}
	var mapCanvas = document.getElementById('googleMap');
	var map = new google.maps.Map(mapCanvas, {
		center: myCenter,
		zoom: zoom
	});
	if(newMarker == 1){
		// var listCousesByCity = coursesByCity(infoCourse);
	
		var icon = {url: '../svg/pin.svg', // url
			scaledSize: new google.maps.Size(60, 60),
		};

		var limites = new google.maps.LatLngBounds();
		var infowindow = new google.maps.InfoWindow();
		var marker,i;
		for (i = 0; i < infoCourse.length; i++) {
			
			marker = new google.maps.Marker({
				position: new google.maps.LatLng(infoCourse[i][2][0], infoCourse[i][2][1]),				 
				animation: google.maps.Animation.BOUNCE,
				icon: icon,
				map: map
			});
			marker.setMap(map);
			if (infoCourse.length != 1)
				limites.extend(marker.position);
			
			google.maps.event.addListener(marker, 'click', (function(marker, i) {
				return function() {
					infowindow.setContent('<strong>' + infoCourse[i][0] + '</strong></br>' + infoCourse[i][1].join('<br>'));
					infowindow.open(map, marker);
				};
			})(marker, i));
		}
		if (infoCourse.length != 1)		
			map.fitBounds(limites);
		
		google.maps.event.addDomListener(window, 'load', myMap);
	}
}
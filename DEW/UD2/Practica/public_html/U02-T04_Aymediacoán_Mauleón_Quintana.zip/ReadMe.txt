Alumno: Aymediaco�n Maule�n Quintana.
 __         ______        __         __     ______     ______     ______     ______               
/\ \       /\  __ \      /\ \       /\ \   /\  ___\   /\  == \   /\  == \   /\  ___\              
\ \ \____  \ \  __ \     \ \ \____  \ \ \  \ \  __\   \ \  __<   \ \  __<   \ \  __\              
 \ \_____\  \ \_\ \_\     \ \_____\  \ \_\  \ \_____\  \ \_____\  \ \_\ \_\  \ \_____\            
  \/_____/   \/_/\/_/      \/_____/   \/_/   \/_____/   \/_____/   \/_/ /_/   \/_____/            
                                                                                                  
                __  __                                                                            
               /\ \_\ \                                                                           
               \ \____ \                                                                          
                \/\_____\                                                                         
                 \/_____/                                                                         
                                                                                                  
 __         ______        ______   ______     ______     ______   __  __     ______     ______    
/\ \       /\  __ \      /\__  _\ /\  __ \   /\  == \   /\__  _\ /\ \/\ \   /\  ___\   /\  __ \   
\ \ \____  \ \  __ \     \/_/\ \/ \ \ \/\ \  \ \  __<   \/_/\ \/ \ \ \_\ \  \ \ \__ \  \ \  __ \  
 \ \_____\  \ \_\ \_\       \ \_\  \ \_____\  \ \_\ \_\    \ \_\  \ \_____\  \ \_____\  \ \_\ \_\ 
  \/_____/   \/_/\/_/        \/_/   \/_____/   \/_/ /_/     \/_/   \/_____/   \/_____/   \/_/\/_/ 
                                                                                                  
Aportaciones al c�digo solicitado:

Se ha a�adido un set de botones y casillas de verificaci�n:
 - Bot�n Reiniciar:
   El cual reinicia los valor para poder realizar una nueva ejecuci�n, tambi�n sirve para parar una carrera en marcha.
 - Bot�n Animado:
   El cual realiza una animaci�n de la carrera en una sola l�nea (se fuerza la activaci�n de la casilla En una l�nea).
 - Casilla En una l�nea:
   Muestra la ejecuci�n de paso a paso en una l�nea cuando est� marcada.
 - Casilla Con im�genes:
   Muestra la carrera utilizando im�genes en lugar de caracteres.

Una vez se comience cualquiera de las ejecuciones, se deshabilitan todos los botones y casillas excepto el bot�n reiniciar, para evitar que comience una nueva ejecuci�n sin que haya terminado la anterior.

## Change Log

#### Version 1.0 Oct 2015

#### jQuery HTML5 Custom Validation Messages plugin
- **(N)** Initial release

### Key
- **(S)** Security Fix
- **(B)** Bug Fix
- **(L)** Language fix or change
- **(A)** Addition
- **(C)** Change
- **(R)** Removed
- **(N)** Note
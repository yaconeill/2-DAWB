Alumno: Aymediaco�n Maule�n Quintana.

Aportaciones al c�digo solicitado:

Se ha a�adido un evento de escucha de cell click, al hacer click en las distintas celdas se va descubriendo una imagen oculta en el fondo.

*(Con m�s tiempo)La intenci�n era hacer un array con imagenes. Se tratar�a de hacer un juego en el que hay que adivinar la imagen oculta y cuantas menos celdas se descubra mayor puntuaci�n tendr�a.
Alumno: Aymediaco�n Maule�n Quintana.

Aportaciones al c�digo solicitado:

Se ha a�adido un bot�n que, estando seleccionado un elemento permirte modificarlo y si se selecciona un color tambien se modifica, se le a�ade tambien un bot�n de ayuda que haciendo hover sobre el muestra una ayuda sobre el color.
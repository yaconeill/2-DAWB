$('use').on('click', function () {
    $(this).toggleClass('selected');
});

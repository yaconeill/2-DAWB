/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.cifpcm.forvago_yaco.web.data;

import es.cifpcm.forvago_yaco.web.model.Provincias;
import java.util.List;

/**
 *
 * @author Yaco
 */
public interface ProvinciasDao {
    public List<Provincias> selectAll();
//
//    public Actor getActor(int actorId);
//
//    public void updateActor(Actor actor);
//
//    public void deleteActor(Actor actor);
//
//    public void insert();
}

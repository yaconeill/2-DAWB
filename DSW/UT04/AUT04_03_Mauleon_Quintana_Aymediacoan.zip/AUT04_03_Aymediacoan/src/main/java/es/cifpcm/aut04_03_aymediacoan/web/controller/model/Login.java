/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.cifpcm.aut04_03_aymediacoan.web.controller.model;

/**
 *
 * @author Yaco
 */
public class Login {

    public String Usuario;

    public Login() {
    }

    public String getUsuario() {
        return Usuario;
    }

    public void setUsuario(String name) {
        this.Usuario = name;
    }
    
}
